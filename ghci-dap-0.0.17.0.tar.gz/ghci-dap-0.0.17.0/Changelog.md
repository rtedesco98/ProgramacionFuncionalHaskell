20220101 ghci-dap-0.0.17.0
  * [INFO] support ghc-9.2.1.


20210815 ghci-dap-0.0.16.0
  * [INFO] support ghc-9.0.1.


20210131 ghci-dap-0.0.15.0
  * [FIX] hda issue #12.
  * [INFO] support ghc-8.10.3.


20200209 ghci-dap-0.0.14.0
  * [INFO] support ghc-8.8.2.


20200105 ghci-dap-0.0.13.0
  * [INFO] support haskell-dap-0.0.14.0.


20190402 ghci-dap-0.0.12.0
  * [INFO] support haskell-dap-0.0.11.0.


20190301 ghci-dap-0.0.11.0
  * [INFO] start developping, based on haskell-dap-0.0.10.0.


