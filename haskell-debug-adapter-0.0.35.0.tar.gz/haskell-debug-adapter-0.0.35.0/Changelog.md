20210815 haskell-debug-adapter-0.0.35.0
  * [INFO] support ghc-9.0.1.


20210131 haskell-debug-adapter-0.0.34.0
  * [FIX] issue#11 Test fails to run
  * [FIX] issue#12 Debugger Freezing/Debug Actions Not Working in Visual Studio
  * [FIX] issue#16 stack.exe and ghci-dap.exe Leak When IDE Not Stopped Properly
  * [FIX][hdx4vim] issue#4 Vimspector official support


20200209 haskell-debug-adapter-0.0.33.0
  * [INFO] support ghci-dap-0.0.14.0.


20200105 haskell-debug-adapter-0.0.32.0
  * [INFO] support haskell-dap-0.0.14.0.
  * [INFO] support ghci-dap-0.0.13.0.


20190505 haskell-debug-adapter-0.0.31.0
  * [MODIFY] refactor some types.


20190402 haskell-debug-adapter-0.0.30.0
  * [INFO] support ghci-dap-0.0.12.0.


20190301 haskell-debug-adapter-0.0.29.0
  * [INFO] start developping, based on phoityne-vscode-0.0.28.0.



