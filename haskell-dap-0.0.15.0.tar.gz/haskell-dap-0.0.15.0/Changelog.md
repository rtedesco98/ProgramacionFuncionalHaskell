20210131 haskell-dap-0.0.15.0

  * [MODIFY] Support ghc-8.10.
  * [FIX] mis-spelling.
  * [FIX] ISSUE#11 defaultSetFunctionBreakpointsResponseBody and defaultScopesResponseBody are not exported


20200105 haskell-dap-0.0.14.0

  * [MODIFY] Support ghc-8.8. (executable is deprecated.)


20190324 haskell-dap-0.0.13.0

  * [ADD] Add force inspect attribute to launch setting.


20190303 haskell-dap-0.0.12.0

  * [FIX] move GHCi.DAP module to Haskell.DAP module.


20190302 haskell-dap-0.0.11.0

  * [ADD] GHCi.DAP module. GHCi.DAP.IFData is deprecated.


20190108 haskell-dap-0.0.10.1

  * [MODIFY] package.yaml build options.


20181201 haskell-dap-0.0.10.0

  * [ADD] Support ghc-8.6


20181014 haskell-dap-0.0.9.0

  * [MODIFY] logpoint output to console.
  * [FIX][[1](https://github.com/phoityne/hdx4vsc/issues/1)]debugger does not work with vscode-1.28.(Fixed with haskell-dap only.)


20180924 haskell-dap-0.0.8.0

  * [ADD] GHCi gobal scope reference.


20180801 haskell-dap-0.0.7.0

  * [ADD] [support ghc-8.4](https://github.com/phoityne/haskell-dap/issues/2)


20180601 haskell-dap-0.0.6.0

  * [MODIFY] support VisualStudio2017.(see [hdx4vs](https://github.com/phoityne/hdx4vsc))
  * [ADD] [ support Logpoints](https://github.com/phoityne/haskell-dap/issues/3)


20180601 haskell-dap-0.0.5.0

  * [ADD] setExceptionBreakpoint commands.
  * [ADD] breakHitCounter, breakCondition, logPoint function.


20180430 haskell-dap-0.0.4.0

  * [ADD] next, stepIn, setFunctionBreakpoint commands.


20180225 haskell-dap-0.0.3.0

  * [ADD] setBreakpoint, continue, scopes, stackTrace, evaluate commands.


20180121 haskell-dap-0.0.2.0

  * [MODIFY] using GHC.Paths module to set libdir.


20180101 haskell-dap-0.0.1.0

  * [INFO] Initial release.

