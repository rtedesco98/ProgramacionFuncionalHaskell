
# haskell-dap

Haskell implementation of the DAP interface data.

@see : https://microsoft.github.io/debug-adapter-protocol/

@see : https://github.com/Microsoft/vscode-debugadapter-node/blob/master/protocol/src/debugProtocol.ts

